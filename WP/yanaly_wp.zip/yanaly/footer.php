<footer>

</footer>

<? wp_footer(); ?>

</body>
</html>