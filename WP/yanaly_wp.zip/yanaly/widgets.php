<?

function footermenuwidgetarea() {
	register_sidebar(
		array(
		'id' => 'footer-menu_widget-area',
		'name' => esc_html__( 'Footer Left', 'yanaly' ),
		'description' => esc_html__( 'Footer Left', 'yanaly' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title-holder"><h3 class="footer-widget-head">',
		'after_title' => '</h3></div>'
		)
	);
}

add_action( 'widgets_init', 'footermenuwidgetarea' );

function footerzvitiwidgetarea() {
	register_sidebar(
		array(
		'id' => 'footer-zviti_widget-area',
		'name' => esc_html__( 'Footer Center', 'yanaly' ),
		'description' => esc_html__( 'Footer Center', 'yanaly' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title-holder"><h3 class="footer-widget-head">',
		'after_title' => '</h3></div>'
		)
	);
}

add_action( 'widgets_init', 'footerzvitiwidgetarea' );

function footerprogramswidgetarea() {
	register_sidebar(
		array(
		'id' => 'footer-programs_widget-area',
		'name' => esc_html__( 'Footer Right', 'yanaly' ),
		'description' => esc_html__( 'Footer Right', 'yanaly' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title-holder"><h3 class="footer-widget-head">',
		'after_title' => '</h3></div>'
		)
	);
}

add_action( 'widgets_init', 'footerprogramswidgetarea' );
?>