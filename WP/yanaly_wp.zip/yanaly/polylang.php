<?php

add_action('init', function() {

	/* HEADER */
	pll_register_string('yanaly_pl_head_menu', 'Menu');
});

?>