<? if ( function_exists( 'pll_the_languages' ) ) {
$translations = pll_the_languages( array( 'dropdown' => 1, 'hide_current' => 1, 'raw' => 1 ) );
} ?>

<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title><? the_title(); ?></title>
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="csrf-token" content="Q1vYs5LjAtlWY4OZLGEVgyaBUjnrXCzM4Dkmmnnj">

<!-- CSS -->
<link rel="stylesheet" href="<? bloginfo('stylesheet_url'); ?>">
<link rel="stylesheet" href="<? echo get_stylesheet_directory_uri().'/css/style.min.css'; ?>">
<link href="https://fonts.cdnfonts.com/css/montserrat" rel="stylesheet" />
<link rel="stylesheet" href="<? echo get_stylesheet_directory_uri().'/css/animate.min.css'; ?>">

<!-- JS -->
<script defer src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script defer src="<? echo get_stylesheet_directory_uri().'/js/script.js'; ?>"></script>
	
<!-- FAVICONS -->
<link rel="apple-touch-icon" sizes="120x120" href="https://yanaly.art/ico/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://yanaly.art/ico/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://yanaly.art/ico/favicon-16x16.png">
<link rel="manifest" href="https://yanaly.art/ico/site.webmanifest">
<link rel="mask-icon" href="https://yanaly.art/ico/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="https://yanaly.art/ico/favicon.ico">
<meta name="apple-mobile-web-app-title" content="Yanaly Art">
<meta name="application-name" content="Yanaly Art">
<meta name="msapplication-TileColor" content="#2b5797">
<meta name="msapplication-config" content="https://yanaly.art/ico/browserconfig.xml">
<meta name="theme-color" content="#ffffff">

<? wp_head(); ?>
</head>
	
<body>
	<? wp_body_open(); ?>
<header>

</header>