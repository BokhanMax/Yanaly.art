<?php
/**
* Template name: Contacts Page
*/
?>

<?php get_header(); ?>

<?php get_footer(); ?>