<?php
/**
* Template name: About Us Page
*/
?>

<?php get_header(); ?>

<?php get_footer(); ?>