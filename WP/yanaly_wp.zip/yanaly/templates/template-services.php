<?php
/**
* Template name: Services Page
*/
?>

<?php get_header(); ?>

<?php get_footer(); ?>