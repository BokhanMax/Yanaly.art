<?php
/**
* Template name: News Page
*/
?>

<?php get_header(); ?>

<?php get_footer(); ?>