<?php
/**
* Template name: Home Page
*/
?>

<?php get_header(); ?>

<?php get_footer(); ?>